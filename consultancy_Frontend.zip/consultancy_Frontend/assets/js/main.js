/**
* Template Name: Arsha
* Template URL: https://bootstrapmade.com/arsha-free-bootstrap-html-template-corporate/
* Updated: Aug 07 2024 with Bootstrap v5.3.3
* Author: BootstrapMade.com
* License: https://bootstrapmade.com/license/
*/

(function() {
  "use strict";

  /**
   * Apply .scrolled class to the body as the page is scrolled down
   */
  function toggleScrolled() {
    const selectBody = document.querySelector('body');
    const selectHeader = document.querySelector('#header');
    if (!selectHeader.classList.contains('scroll-up-sticky') && !selectHeader.classList.contains('sticky-top') && !selectHeader.classList.contains('fixed-top')) return;
    window.scrollY > 100 ? selectBody.classList.add('scrolled') : selectBody.classList.remove('scrolled');
  }

  document.addEventListener('scroll', toggleScrolled);
  window.addEventListener('load', toggleScrolled);

  /**
   * Mobile nav toggle
   */
  const mobileNavToggleBtn = document.querySelector('.mobile-nav-toggle');

  function mobileNavToogle() {
    document.querySelector('body').classList.toggle('mobile-nav-active');
    mobileNavToggleBtn.classList.toggle('bi-list');
    mobileNavToggleBtn.classList.toggle('bi-x');
  }
  mobileNavToggleBtn.addEventListener('click', mobileNavToogle);

  /**
   * Hide mobile nav on same-page/hash links
   */
  document.querySelectorAll('#navmenu a').forEach(navmenu => {
    navmenu.addEventListener('click', () => {
      if (document.querySelector('.mobile-nav-active')) {
        mobileNavToogle();
      }
    });

  });

  /**
   * Toggle mobile nav dropdowns
   */
  document.querySelectorAll('.navmenu .toggle-dropdown').forEach(navmenu => {
    navmenu.addEventListener('click', function(e) {
      e.preventDefault();
      this.parentNode.classList.toggle('active');
      this.parentNode.nextElementSibling.classList.toggle('dropdown-active');
      e.stopImmediatePropagation();
    });
  });

  /**
   * Preloader
   */
  const preloader = document.querySelector('#preloader');
  if (preloader) {
    window.addEventListener('load', () => {
      preloader.remove();
    });
  }

  /**
   * Scroll top button
   */
  let scrollTop = document.querySelector('.scroll-top');

  function toggleScrollTop() {
    if (scrollTop) {
      window.scrollY > 100 ? scrollTop.classList.add('active') : scrollTop.classList.remove('active');
    }
  }
  scrollTop.addEventListener('click', (e) => {
    e.preventDefault();
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  });

  window.addEventListener('load', toggleScrollTop);
  document.addEventListener('scroll', toggleScrollTop);

  /**
   * Animation on scroll function and init
   */
  function aosInit() {
    AOS.init({
      duration: 600,
      easing: 'ease-in-out',
      once: true,
      mirror: false
    });
  }
  window.addEventListener('load', aosInit);

  /**
   * Initiate glightbox
   */
  const glightbox = GLightbox({
    selector: '.glightbox'
  });

  /**
   * Init swiper sliders
   */
  function initSwiper() {
    document.querySelectorAll(".init-swiper").forEach(function(swiperElement) {
      let config = JSON.parse(
        swiperElement.querySelector(".swiper-config").innerHTML.trim()
      );

      if (swiperElement.classList.contains("swiper-tab")) {
        initSwiperWithCustomPagination(swiperElement, config);
      } else {
        new Swiper(swiperElement, config);
      }
    });
  }

  window.addEventListener("load", initSwiper);

  /**
   * Frequently Asked Questions Toggle
   */
  document.querySelectorAll('.faq-item h3, .faq-item .faq-toggle').forEach((faqItem) => {
    faqItem.addEventListener('click', () => {
      faqItem.parentNode.classList.toggle('faq-active');
    });
  });

  /**
   * Animate the skills items on reveal
   */
  let skillsAnimation = document.querySelectorAll('.skills-animation');
  skillsAnimation.forEach((item) => {
    new Waypoint({
      element: item,
      offset: '80%',
      handler: function(direction) {
        let progress = item.querySelectorAll('.progress .progress-bar');
        progress.forEach(el => {
          el.style.width = el.getAttribute('aria-valuenow') + '%';
        });
      }
    });
  });

  /**
   * Init isotope layout and filters
   */
  document.querySelectorAll('.isotope-layout').forEach(function(isotopeItem) {
    let layout = isotopeItem.getAttribute('data-layout') ?? 'masonry';
    let filter = isotopeItem.getAttribute('data-default-filter') ?? '*';
    let sort = isotopeItem.getAttribute('data-sort') ?? 'original-order';

    let initIsotope;
    imagesLoaded(isotopeItem.querySelector('.isotope-container'), function() {
      initIsotope = new Isotope(isotopeItem.querySelector('.isotope-container'), {
        itemSelector: '.isotope-item',
        layoutMode: layout,
        filter: filter,
        sortBy: sort
      });
    });

    isotopeItem.querySelectorAll('.isotope-filters li').forEach(function(filters) {
      filters.addEventListener('click', function() {
        isotopeItem.querySelector('.isotope-filters .filter-active').classList.remove('filter-active');
        this.classList.add('filter-active');
        initIsotope.arrange({
          filter: this.getAttribute('data-filter')
        });
        if (typeof aosInit === 'function') {
          aosInit();
        }
      }, false);
    });

  });

  /**
   * Correct scrolling position upon page load for URLs containing hash links.
   */
  window.addEventListener('load', function(e) {
    if (window.location.hash) {
      if (document.querySelector(window.location.hash)) {
        setTimeout(() => {
          let section = document.querySelector(window.location.hash);
          let scrollMarginTop = getComputedStyle(section).scrollMarginTop;
          window.scrollTo({
            top: section.offsetTop - parseInt(scrollMarginTop),
            behavior: 'smooth'
          });
        }, 100);
      }
    }
  });

  /**
   * Navmenu Scrollspy
   */
  let navmenulinks = document.querySelectorAll('.navmenu a');

  function navmenuScrollspy() {
    navmenulinks.forEach(navmenulink => {
      if (!navmenulink.hash) return;
      let section = document.querySelector(navmenulink.hash);
      if (!section) return;
      let position = window.scrollY + 200;
      if (position >= section.offsetTop && position <= (section.offsetTop + section.offsetHeight)) {
        document.querySelectorAll('.navmenu a.active').forEach(link => link.classList.remove('active'));
        navmenulink.classList.add('active');
      } else {
        navmenulink.classList.remove('active');
      }
    })
  }
  window.addEventListener('load', navmenuScrollspy);
  document.addEventListener('scroll', navmenuScrollspy);

})();
$(document).ready(function() {
  toastr.options = {
    "closeButton": true,
    "debug": false,
    "newestOnTop": false,
    "progressBar": true,
    "positionClass": "toast-top-right",
    "preventDuplicates": false,
    "onclick": null,
    "showDuration": "300",
    "hideDuration": "1000",
    "timeOut": "5000",
    "extendedTimeOut": "1000",
    "showEasing": "swing",
    "hideEasing": "linear",
    "showMethod": "fadeIn",
    "hideMethod": "fadeOut"
  };

  function validateInputOnBlur(inputId, errorMessage, regexPattern) {
    $(inputId).on('blur', function() {
      const inputValue = $(this).val().trim();
      if (!regexPattern.test(inputValue)) {
        toastr.error(errorMessage, 'Validation Error');
      }
      checkFormValidity(); // Check form validity whenever input loses focus
    });
  }

  function checkFormValidity() {
    let isValid = true;

    // Validate Company Name
    const companyName = $('#companyname').val().trim();
    if (companyName === "" || !/^[a-zA-Z\s]+$/.test(companyName)) {
      isValid = false;
    }

    // Validate Name
    const recipientName = $('#recipient-name').val().trim();
    if (recipientName === "" || !/^[a-zA-Z\s]+$/.test(recipientName)) {
      isValid = false;
    }

    // Validate Email
    const email = $('#email').val().trim();
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (email === "" || !emailPattern.test(email)) {
      isValid = false;
    }

    // Validate Contact
    const phoneNumber = $('#number').val().trim();
    if (phoneNumber === "" || !/^\d{10}$/.test(phoneNumber)) {
      isValid = false;
    }

    // Validate Message
    const messageText = $('#message-text').val().trim();
    if (messageText === "") {
      isValid = false;
    }

    $('#sendButton').prop('disabled', !isValid); // Enable or disable the button based on validity
  }

  // Initialize input validation on blur
  validateInputOnBlur('#companyname', "Please fill the company name with letters only.", /^[a-zA-Z\s]+$/);
  validateInputOnBlur('#recipient-name', "Please fill the name with letters only.", /^[a-zA-Z\s]+$/);
  validateInputOnBlur('#email', "Please enter a valid email address.", /^[^\s@]+@[^\s@]+\.[^\s@]+$/);
  validateInputOnBlur('#number', "Please enter a 10-digit contact number.", /^\d{10}$/);
  validateInputOnBlur('#message-text', "Please fill the message.", /.+/);

  // Check validity on input change
  $('form').on('input', function() {
    checkFormValidity();
  });

  // Clear form and validation messages when the modal is closed
  $('#exampleModal').on('hidden.bs.modal', function() {
    $(this).find('form')[0].reset();  // Clear form fields
    $('#sendButton').prop('disabled', true); // Disable the button when the modal is closed
  });

  $('#sendButton').on('click', function(e) {
    e.preventDefault(); // Prevent default form submission

    let isValid = true;

    // Validate Company Name
    const companyName = $('#companyname').val().trim();
    if (companyName === "" || !/^[a-zA-Z\s]+$/.test(companyName)) {
      toastr.error("Please fill the company name with letters only.", 'Validation Error');
      isValid = false;
    }

    // Validate Name
    const recipientName = $('#recipient-name').val().trim();
    if (recipientName === "" || !/^[a-zA-Z\s]+$/.test(recipientName)) {
      toastr.error("Please fill the name with letters only.", 'Validation Error');
      isValid = false;
    }

    // Validate Email
    const email = $('#email').val().trim();
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (email === "" || !emailPattern.test(email)) {
      toastr.error("Please enter a valid email address.", 'Validation Error');
      isValid = false;
    }

    // Validate Contact
    const phoneNumber = $('#number').val().trim();
    if (phoneNumber === "" || !/^\d{10}$/.test(phoneNumber)) {
      toastr.error("Please enter a 10-digit contact number.", 'Validation Error');
      isValid = false;
    }

    // Validate Message
    const messageText = $('#message-text').val().trim();
    if (messageText === "") {
      toastr.error("Please fill the message.", 'Validation Error');
      isValid = false;
    }

    if (isValid) {
      console.log('Attempting to hide modal...'); 
      $('#exampleModal').modal('hide'); // Hide the modal
      console.log('Modal hide called');
      toastr.success('Successfully updated.', 'Success', { timeOut: 5000 });
    }
  });

  // Initialize the button state
  $('#sendButton').prop('disabled', true); // Disable button initially
});

document.getElementById('contact-form').addEventListener('submit', async function (event) {
  event.preventDefault(); // Prevent default form submission

  // Get form data
  const formData = {
      name: document.getElementById('name-field').value,
      email: document.getElementById('email-field').value,
      subject: document.getElementById('subject-field').value,
      message: document.getElementById('message-field').value
  };

  // Basic form validation
  if (!formData.name || !formData.email || !formData.subject || !formData.message) {
      toastr.error('Please fill out all fields.', 'Error');
      return; // Stop the form submission
  }

  // Further validation (e.g., email format)
  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailPattern.test(formData.email)) {
      toastr.error('Please enter a valid email address.', 'Error');
      return; // Stop the form submission
  }

  try {
      // Send a POST request to the backend
      const response = await fetch('http://localhost:3000/send', {
          method: 'POST',
          headers: {
              'Content-Type': 'application/json'
          },
          body: JSON.stringify(formData)
      });

      // Get the response message
      const result = await response.text();

      if (response.ok) {
          toastr.success(result, 'Success');
      } else {
          toastr.error(result, 'Error');
      }
  } catch (error) {
      console.error('Error:', error);
      toastr.error('Failed to send email.', 'Error');
  }
});

toastr.options = {
  "closeButton": true,
  "debug": false,
  "newestOnTop": false,
  "progressBar": true,
  "positionClass": "toast-top-right",
  "preventDuplicates": false,
  "onclick": null,
  "showDuration": "300",
  "hideDuration": "1000",
  "timeOut": "5000",
  "extendedTimeOut": "1000",
  "showEasing": "swing",
  "hideEasing": "linear",
  "showMethod": "fadeIn",
  "hideMethod": "fadeOut"
};


document.getElementById('sendButton').addEventListener('click', async function (event) {
  event.preventDefault(); // Prevent default form submission

  // Get form data
  const formData = {
    companyname: document.getElementById('companyname').value,
    recipientName: document.getElementById('recipient-name').value,
    email: document.getElementById('email').value,
    contact: document.getElementById('number').value,
    message: document.getElementById('message-text').value
  };

  try {
    // Send a POST request to the backend
    const response = await fetch('http://localhost:3000/send-contact-form', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(formData)
    });

    // Get the response message
    const result = await response.text();
    document.getElementById('response-message').innerText = result; // Show success message on frontend
    if (response.ok) {
      document.getElementById('response-message').style.color = 'green'; // Style for success
    } else {
      document.getElementById('response-message').style.color = 'red'; // Style for error
    }
  } catch (error) {
    console.error('Error:', error);
    document.getElementById('response-message').innerText = 'Failed to send email.';
    document.getElementById('response-message').style.color = 'red';
  }
});

const phoneInputField = document.querySelector("#number");
const phoneInput = window.intlTelInput(phoneInputField, {
  utilsScript:
    "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/utils.js",
    initialCountry: "in" 
});
function myFunction() {
  var dots = document.getElementById("dots");
  var moreText = document.getElementById("more");
  var btnText = document.getElementById("myBtn");

  if (dots.style.display === "none") {
    dots.style.display = "inline";
    btnText.innerHTML = "Read more";
    moreText.style.display = "none";
  } else {
    dots.style.display = "none";
    btnText.innerHTML = "Read less";
    moreText.style.display = "inline";
  }
}
document.addEventListener('DOMContentLoaded', function() {
  const texts = [
    'Bridging the gap between talent and opportunity for transformative business impact',
    'Your Partner in Innovative Software Development & IT Services'
  ];
  
  let currentIndex = 0;
  const rotatingText = document.getElementById('rotating-text');
  
  function changeText() {
    rotatingText.classList.add('hidden'); // Start fade-out effect
    
    setTimeout(() => {
      currentIndex = (currentIndex + 1) % texts.length;
      rotatingText.textContent = texts[currentIndex];
      rotatingText.classList.remove('hidden'); // Start fade-in effect
    }, 1000); // Match this to the fade-out duration
    
  }
  
  // Change text every 5 seconds
  setInterval(changeText, 5000);
});






